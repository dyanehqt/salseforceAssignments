var i = 0;
var images = [];
var timer = 2000;

images[0] = "img/img1s.jpg";
images[1] = "img/img2s.jpg";
images[2] = "img/img3s.jpg";

function changeImage()
{
    document.baba.src = images[i];
    if(i <images.length-1)
    {
        i++;
    }
    else
    {
        i=0;
    }
    setTimeout("changeImage()",timer);
}
window.onload = changeImage;