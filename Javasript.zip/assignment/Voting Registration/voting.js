const validation =()=> {
    var name = document.getElementById('name').value;
    var dob = document.getElementById('dob').value;
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    var namereg = new RegExp("^[a-z A-Z_]*$")
    var usernameregg = new RegExp("^[0-9 a-z A-Z]*$");
    var passwordregg = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).*$");

    var names = true;
    var dates = true;
    var usernames = true;
    var passwords = true;

    var today = new Date();
    var age = currentyear - year;

    let dobs = new Date(dob);
    let year = dobs.getFullYear();
    let currentyear = today.getFullYear();
    
    if(name.length <=0){
        document.getElementById("NameError").innerHTML="Name is Required"
        names = false;
    }else if (!namereg.test(name)){
        document.getElementById("NameError").innerHTML="Alphabet Only"
        names = false;
    }
    if(dob.length<=0){
        document.getElementById("DateError").innerHTML="Date is required"
        dates = false;
    }else if(!(typeof(new Date(dob))=='object')){
        document.getElementById("DateError").innerHTML="Date is not in the proper format"
        dates = false;
    }
    if(username.length <=0){
        document.getElementById("UsernameError").innerHTML="Username is Required"
        username = false;
    }else if (username.length!=8){
        document.getElementById("UsernameError").innerHTML="must in 8 Alphanumeric format"
        username = false;
    }else if (!usernameregg.test(username)){
        document.getElementById("UsernameError").innerHTML="Username must consist Alphanumeric"
        username = false;
    }
    if(password.length <=0){
        document.getElementById("PasswordError").innerHTML="Password is Required"
        password = false;
    }else if (username.length!=8-16){
        document.getElementById("PasswordError").innerHTML="must in 8-16 password format"
        password = false;
    }else if (!passwordregg.test(password)){
        document.getElementById("PasswordError").innerHTML="Password must consist atleast 1 uppercase letter, atleast 1 lowercase, atleast 1 number "
        password = false;
    }
    if(age >= 18 || age !=0){
        alert("Your registration as a voter was successful!");
    }else{
        alert("Voters must be more than 18 Years old")
    }
}
