var i = 0;
var images = [];
var time = 100;

images[0] = "image/img1.png";
images[1] = "image/img2.png";
images[2] = "image/img3.png";
images[3] = "image/img4.png";
images[4] = "image/img5.png";
images[5] = "image/img6.png";
images[6] = "image/img7.png";
images[7] = "image/img8.png";

function changeImg()
{
    document.xxx.src = images[i];
    if(i<images.length-1)
    {
        i++;
    }
    else
    {
        i=0;
    }
    setTimeout("changeImg()",time);
}
window.onload = changeImg;