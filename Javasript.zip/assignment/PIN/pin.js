const validation =()=>{
    var name = document.getElementById('name').value;
    var dob = document.getElementById('dob').value;
    var phone = document.getElementById('phone').value;
    var namereg = new RegExp("^[a-z A-Z_]*$")
    var phonereg = new RegExp("^[0-9]");
    var names = true;
    var dates = true;
    var phones = true;

    if(name.length <=0){
        document.getElementById("NameError").innerHTML="Name is Required"
        names = false;
    }else if (!namereg.test(name)){
        document.getElementById("NameError").innerHTML="Name is not in the proper format"
        names = false;
    }
    if(phone.length <=0){
        document.getElementById("PhoneError").innerHTML="Phone Number is Required"
        phones = false;
    }else if (phone.length!=10){
        document.getElementById("PhoneError").innerHTML="must in 10 digits Phone Number format"
        phones = false;
    }else if (!phonereg.test(phone)){
        document.getElementById("PhoneError").innerHTML="Phone Number is not in the proper format"
        phones = false;
    }
    if(dob.length<=0){
        document.getElementById("DateError").innerHTML="Date is required"
        dates = false;
    }else if(!(typeof(new Date(dob))=='object')){
        document.getElementById("DateError").innerHTML="Date is not in the proper format"
        dates = false;
    }
    console.log()
    if(names && dates && phones){
        console.log(dob.split("-"))
        var dates = dob.split("-")[2]+dob.split("-")[1]+dob.split("-")[0].substring(2,4)
        alert('pin: '+ name.substring(0,4)+dates+phone.substring(5,10))
        document.getElementById("DateError").innerHTML=""
        document.getElementById("PhoneError").innerHTML=""
        document.getElementById("NameError").innerHTML=""
    }
}